package com.example.bobatap;

public class Constants {

    public static final String PREF_NAME = "pref_name", PREF_STORED = "pref_store",
            PREF_URL = "pref_url", PREF_DIRECTORY = "pref_direct";

    public static final String KEY_PREFERENCE_NAME ="socialMediapreference";
    public static final String KEY_IS_SIGNED_IN = "is_signed_in";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_NAME = "name";
    public static final String KEY_IMAGE = "image";
    public static final String KEY_COLLECTION_USERS = "users";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PASSWORD = "password";
}
